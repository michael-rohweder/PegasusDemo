﻿namespace PegasusDemo
{
    public interface IFlyingAnimal : IGeneralAnimal
    {
        void Fly();
        void Land();
    }
}