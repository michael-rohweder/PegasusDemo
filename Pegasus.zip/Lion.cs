﻿namespace PegasusDemo
{
    public class Lion : ILandAnimal
    {
        public int numLegs { get; set;}
        public string Name { get; set;}
        public double Weight { get; set; }

        public void Eat()
        {
            System.Console.WriteLine("Going on a hunt!");
        }

        public void Sleep()
        {
            System.Console.WriteLine("Going to sleep now!");
        }

        public void Walk()
        {
            System.Console.WriteLine("Moving over here!");
        }
    }
}