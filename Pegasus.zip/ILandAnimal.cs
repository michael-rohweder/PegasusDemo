﻿namespace PegasusDemo
{
    public interface ILandAnimal : IGeneralAnimal
    {
        int numLegs { get; set; }
        void Walk();
    }
}