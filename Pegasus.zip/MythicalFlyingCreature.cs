﻿namespace PegasusDemo
{
    public abstract class MythicalFlyingCreature : ILandAnimal, IFlyingAnimal
    {
        public string Name { get; set; }
        public double Weight { get; set; }
        public int numLegs { get; set; }

        public void Eat()
        {
            System.Console.WriteLine("YUMMY!");
        }

        public void Fly()
        {
            System.Console.WriteLine("Up, Up, and Away!!");
        }

        public void Land()
        {
            System.Console.WriteLine("Going Down!");
        }

        public void Sleep()
        {
            System.Console.WriteLine("ZZZZZZzzzzzzzz");            
        }

        public void Walk()
        {
            System.Console.WriteLine("Clip-Clop, Clip-Clop");
        }
    }
}