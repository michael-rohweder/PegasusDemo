﻿namespace PegasusDemo
{
    public class Pegasus : MythicalFlyingCreature
    {
    }
}