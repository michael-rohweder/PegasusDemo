﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PegasusDemo
{
    internal partial class Program
    {
        static void Main(string[] args)
        {
            Pegasus pegasus = new Pegasus() { numLegs = 4, Name = "Pegasus", Weight=500};
            pegasus.Walk();
            pegasus.Eat();
            pegasus.Fly();
            pegasus.Sleep();
            Console.WriteLine("The {0} weighs {1}lbs!", pegasus.Name, pegasus.Weight);
            Console.WriteLine();
            Lion lion = new Lion() { numLegs=4, Name="Leo The Lion", Weight=200};
            lion.Walk();
            lion.Eat();
            lion.Sleep();
            Console.WriteLine("{0} weighs {1}lbs!", lion.Name, lion.Weight);
            Console.ReadLine();
        }
    }
}