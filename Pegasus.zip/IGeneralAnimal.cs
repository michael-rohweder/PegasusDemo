﻿namespace PegasusDemo
{
    public interface IGeneralAnimal
    {
        string Name { get; set; }
        double Weight { get; set; }

        void Eat();
        void Sleep();
        
    }
}