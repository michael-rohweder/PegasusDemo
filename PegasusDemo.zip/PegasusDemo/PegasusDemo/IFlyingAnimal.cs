﻿namespace PegasusDemo
{
    public interface IFlyingAnimal : ILandAnimal
    {
        void Fly();
    }
}