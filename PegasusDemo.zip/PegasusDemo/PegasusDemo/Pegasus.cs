﻿namespace PegasusDemo
{
    public class Pegasus : IFlyingAnimal
    {
        public string Name { get; set; }
        public double Weight { get; set; }

        public void Eat()
        {
            System.Console.WriteLine("YUMMY!");
        }

        public void Fly()
        {
            System.Console.WriteLine("Up, Up, and Away!!");
        }

        public void Sleep()
        {
            System.Console.WriteLine("ZZZZZZzzzzzzzz");            
        }

        public void Walk()
        {
            System.Console.WriteLine("Clip-Clop, Clip-Clop");
        }
    }
}