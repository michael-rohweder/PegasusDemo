﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PegasusDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pegasus pegasus = new Pegasus();
            pegasus.Name = "Pegasus";
            pegasus.Weight = 500;
            pegasus.Walk();
            pegasus.Eat();
            pegasus.Fly();
            Console.WriteLine("The {0} weighs {1}lbs!", pegasus.Name, pegasus.Weight);
            Console.ReadLine();
        }
    }
}