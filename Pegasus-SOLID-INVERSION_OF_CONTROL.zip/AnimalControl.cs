﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace PegasusDemo
{
    internal class AnimalControl
    {
        static readonly List<IGeneralAnimal> animals = new List<IGeneralAnimal>();

        public static List<IGeneralAnimal> GetAnimalList()
        {
            return animals;  //Return the current list of animals to caller
        }

        public static object CreateAndAddAnimal(Type type, string name="", double weight=0)
        {
            var animal = (IGeneralAnimal)Activator.CreateInstance(type);
            animal.Weight = weight;
            animal.Name = name;
            AnimalControl.AddAnimal(animal);
            return animal;
        }

        public static void AddAnimal<T>(T animal)
        {
            animals.Add(animal as IGeneralAnimal);  //Add a new animal to the list
        }
        public static void CycleAnimals()
        {
            foreach (var animal in animals)  
            {
                AnimalControl.Eat(animal);
                AnimalControl.Sleep(animal);
                AnimalControl.Walk(animal);
                AnimalControl.Fly(animal);
                AnimalControl.Land(animal);

                PrintCommands.PrintAnimalData<IGeneralAnimal>(animal);
                PrintCommands.PrintBlankLine();
            }
        }

        // Eat Method
        public static void Eat<T>(T animal) where T : IGeneralAnimal
        {
            animal.Eat();
        }

        //Sleep Method
        public static void Sleep<T>(T animal) where T : IGeneralAnimal
        {
            animal.Sleep();
        }

        //Walk Method
        public static void Walk<T>(T animal) where T : IGeneralAnimal
        {
            var interfaces = animal.GetType().GetInterfaces();
            if (Array.IndexOf(interfaces, typeof(ILandAnimal)) != -1)
            {
                var landAnimal = animal as ILandAnimal;
                landAnimal.Walk();
            }
        }

        //Fly Method
        public static void Fly<T>(T animal) where T : IGeneralAnimal
        {
            var interfaces = animal.GetType().GetInterfaces();
            if (Array.IndexOf(interfaces, typeof(IFlyingAnimal)) != -1)
            {
                var flyingAnimal = animal as IFlyingAnimal;
                flyingAnimal.Fly();
            }
        }

        //Land Method
        public static void Land<T>(T animal) where T : IGeneralAnimal
        {
            var interfaces = animal.GetType().GetInterfaces();
            if (Array.IndexOf(interfaces, typeof(IFlyingAnimal)) != -1)
            {
                var flyingAnimal = animal as IFlyingAnimal;
                flyingAnimal.Land();
            }
        }
    }
}
