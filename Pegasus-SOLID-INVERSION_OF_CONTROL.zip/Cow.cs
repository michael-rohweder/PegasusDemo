﻿namespace PegasusDemo
{
    public class Cow : LandAnimal
    {
        public override void Eat()
        {
            PrintCommands.Print("MMmmmm.... Grass.....");
        }
    }
}