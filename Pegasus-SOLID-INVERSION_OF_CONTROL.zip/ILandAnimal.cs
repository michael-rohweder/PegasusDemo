﻿namespace PegasusDemo
{
    //Land animal interface
    public interface ILandAnimal : IGeneralAnimal
    {
        void Walk();
    }
}