﻿namespace PegasusDemo
{
    public abstract class FlyingAnimal : IFlyingAnimal
    {
        public string Name { get; set; }
        public double Weight { get; set; }

        public void Eat()
        {
            PrintCommands.Print("Peck Peck");
        }

        public void Fly()
        {
            PrintCommands.Print("Flapping those wings!");
        }

        public void Land()
        {
            PrintCommands.Print("Coming down!");
        }

        public void Sleep()
        {
            PrintCommands.Print("Im getting sleepy!");
        }
    }
}