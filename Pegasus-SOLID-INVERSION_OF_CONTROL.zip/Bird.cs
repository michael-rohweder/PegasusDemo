﻿namespace PegasusDemo
{
    public class Bird : FlyingAnimal
    {
    }
}