﻿namespace PegasusDemo
{
    //Abstract class for MythicalFlyingCreatures : Inherits from LandAnimal and IFlyingAnimal
    public abstract partial class MythicalFlyingCreature : IMythicalFlyingCreature
    {
        public string Name { get; set; }
        public double Weight { get; set;}

        public virtual void Eat()
        {
            System.Console.WriteLine("This food is MYTHICALLY GOOD!");
        }

        //Default Fly Method
        public virtual void Fly()
        {
            System.Console.WriteLine("Mythical Flying is best!");
        }

        //Default Land Method
        public virtual void Land()
        {
            System.Console.WriteLine("Lets get these hooves on the ground!");
        }

        public virtual void Sleep()
        {
            System.Console.WriteLine("ZZZZzzzzzz");
        }

        public virtual void Walk()
        {
            System.Console.WriteLine("Clip-Clop, Clip-Clop");
        }
    }
}