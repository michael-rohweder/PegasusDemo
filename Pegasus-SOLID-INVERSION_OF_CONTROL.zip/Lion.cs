﻿namespace PegasusDemo
{
    public class Lion : LandAnimal
    {
        //Override the default Eat method
        public override void Eat()
        {
            PrintCommands.Print("Going Hunting!");
        }
    }
}