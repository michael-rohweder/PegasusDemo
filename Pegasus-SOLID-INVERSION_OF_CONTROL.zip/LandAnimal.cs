﻿namespace PegasusDemo
{
    public abstract class LandAnimal : ILandAnimal
    {
        public string Name { get; set; }
        public double Weight { get; set; }

        //Default Eat method
        public virtual void Eat()
        {
            PrintCommands.Print("DINNER TIME!");
        }

        //Default Sleep method
        public virtual void Sleep()
        {
            PrintCommands.Print("Good night!");        
        }

        //Default Walk method
        public virtual void Walk()
        {
            PrintCommands.Print("Going for a walk!");        
        }
    }
}