﻿using System;

namespace PegasusDemo
{
    /// <summary>
    /// General Flow Control of Program
    /// Adds Animals, the loops through their methods.
    /// </summary>
    internal partial class Program
    {
        static void Main(string[] args)
        {
            var pegasus = AnimalControl.CreateAndAddAnimal(typeof(Pegasus), "Ronnie", 500);
            var lion = AnimalControl.CreateAndAddAnimal(typeof(Lion), "Leo", 200);
            var cow = AnimalControl.CreateAndAddAnimal(typeof(Cow), "Theo", 350);
            var bird = AnimalControl.CreateAndAddAnimal(typeof(Bird), "Tweety", 1);

            AnimalControl.CycleAnimals();
            
            Console.ReadLine();
        }
    }
}