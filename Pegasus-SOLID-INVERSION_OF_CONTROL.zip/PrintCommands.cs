﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PegasusDemo
{
    internal class PrintCommands
    {

        public static void Print(string message)
        {
            Console.WriteLine(message);
        }
        //Print the animal specific data
        public static void PrintAnimalData<T>(T animal) where T : IGeneralAnimal
        {
            PrintCommands.Print(String.Format("The {0} named {1} weighs {2}LBS!", animal.GetType().Name, animal.Name, animal.Weight));
        }

        //Print a blank line
        public static void PrintBlankLine()
        {
            PrintCommands.Print("");
        }
    }
}
