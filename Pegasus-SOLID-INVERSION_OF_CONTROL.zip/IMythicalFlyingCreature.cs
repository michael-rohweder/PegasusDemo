﻿namespace PegasusDemo
{
        public interface IMythicalFlyingCreature : ILandAnimal, IFlyingAnimal
        {

        }
}