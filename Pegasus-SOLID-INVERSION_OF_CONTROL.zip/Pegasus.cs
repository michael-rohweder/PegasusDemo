﻿namespace PegasusDemo
{
    public class Pegasus : MythicalFlyingCreature
    {
        public override void Walk()
        {
            PrintCommands.Print("Clip-Clop!");
        }

        public override void Fly()
        {
            PrintCommands.Print("This Bird/Horse is going up!");
        }
    }
}