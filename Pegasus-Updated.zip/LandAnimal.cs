﻿namespace PegasusDemo
{
    public abstract class LandAnimal : ILandAnimal
    {
        public int numLegs { get; set; }
        public string Name { get; set; }
        public double Weight { get; set; }

        //Default Eat method
        public virtual void Eat()
        {
            System.Console.WriteLine("DINNER TIME!");
        }

        //Default Sleep method
        public virtual void Sleep()
        {
            System.Console.WriteLine("Good night!");        
        }

        //Default Walk method
        public virtual void Walk()
        {
            System.Console.WriteLine("Going for a walk!");        
        }
    }
}