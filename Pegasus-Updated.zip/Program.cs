﻿using System;

namespace PegasusDemo
{
    internal partial class Program
    {
        static void Main(string[] args)
        {
            //Add three animals into the AnimalControl List
            AnimalControl.AddAnimal(new Pegasus() { numLegs=4, Name="Ronnie", Weight=500});
            AnimalControl.AddAnimal(new Lion() { numLegs=4, Name="Leo The Lion", Weight=200});
            AnimalControl.AddAnimal(new Lion() { numLegs = 4, Name = "Theo", Weight = 350 });
            
            //Cycle through the list of methods for each animal in AnimalControl
            AnimalControl.CycleAnimals();
            
            //Pause execution so that the screen stays
            Console.ReadLine();
        }

        
    }
}