﻿namespace PegasusDemo
{
    //Abstract class for MythicalFlyingCreatures : Inherits from LandAnimal and IFlyingAnimal
    public abstract class MythicalFlyingCreature : LandAnimal, IFlyingAnimal
    {
        //Default Fly Method
        public virtual void Fly()
        {
            System.Console.WriteLine("Up, Up, and Away!!");
        }

        //Default Land Method
        public virtual void Land()
        {
            System.Console.WriteLine("Going Down!");
        }
    }
}