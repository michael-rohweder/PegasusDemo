﻿namespace PegasusDemo
{
    //Land animal interface
    public interface ILandAnimal : IGeneralAnimal
    {
        int numLegs { get; set; }
        void Walk();
    }
}