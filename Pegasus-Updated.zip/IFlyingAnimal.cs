﻿namespace PegasusDemo
{
    //Flying animal interface
    public interface IFlyingAnimal : IGeneralAnimal
    {
        void Fly();
        void Land();
    }
}