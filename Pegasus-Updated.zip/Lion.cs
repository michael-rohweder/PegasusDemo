﻿namespace PegasusDemo
{
    public class Lion : LandAnimal
    {
        //Override the default Eat method
        public override void Eat()
        {
            System.Console.WriteLine("Going Hunting!");
        }
    }
}