﻿namespace PegasusDemo
{
    public class Pegasus : MythicalFlyingCreature
    {
        //Override the default Walk method
        public override void Walk()
        {
            System.Console.WriteLine("Clip-Clop!");
        }
    }
}