﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PegasusDemo
{
    internal class PrintCommands
    {
        //Print the animal specific data
        public static void PrintAnimalData<T>(T animal) where T : IGeneralAnimal
        {
            Console.WriteLine("The {0} named {1} weighs {2}lbs!", animal.GetType().Name, animal.Name, animal.Weight);
        }

        //Print a blank line
        public static void PrintBlankLine()
        {
            Console.WriteLine();
        }
    }
}
