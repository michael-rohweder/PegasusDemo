﻿using System.Collections.Generic;

namespace PegasusDemo
{
    internal class AnimalControl
    {
        static List<IGeneralAnimal> animals = new List<IGeneralAnimal>();

        public static List<IGeneralAnimal> GetAnimalList()
        {
            return animals;  //Return the current list of animals to caller
        }

        public static void AddAnimal<T>(T animal)
        {
            animals.Add(animal as IGeneralAnimal);  //Add a new animal to the list
        }
        public static void CycleAnimals()
        {
            foreach (var animal in animals)  //Cycle through the methods of the animals
            {
                AnimalControl.Eat(animal);
                AnimalControl.Sleep(animal);
                AnimalControl.Walk(animal);
                AnimalControl.Fly(animal);
                AnimalControl.Land(animal);

                PrintCommands.PrintAnimalData<IGeneralAnimal>(animal); //Print the animal specific data
                PrintCommands.PrintBlankLine();
            }
        }

        // Eat Method
        public static void Eat<T>(T animal) where T : IGeneralAnimal
        {
            animal.Eat();
        }

        //Sleep Method
        public static void Sleep<T>(T animal) where T : IGeneralAnimal
        {
            animal.Sleep();
        }

        //Walk Method
        public static void Walk<T>(T animal) where T : IGeneralAnimal
        {
            if (animal.GetType().BaseType == typeof(LandAnimal) || animal.GetType().BaseType == typeof(MythicalFlyingCreature))
            {
                var landAnimal = animal as LandAnimal;
                landAnimal.Walk();
            }
        }

        //Fly Method
        public static void Fly<T>(T animal) where T : IGeneralAnimal
        {
            if (animal.GetType().BaseType == typeof(MythicalFlyingCreature))
            {
                var mythicalAnimal = animal as MythicalFlyingCreature;
                mythicalAnimal.Fly();
            }
        }

        //Land Method
        public static void Land<T>(T animal) where T : IGeneralAnimal
        {
            if (animal.GetType().BaseType == typeof(MythicalFlyingCreature))
            {
                var mythicalAnimal = animal as MythicalFlyingCreature;
                mythicalAnimal.Land();
            }
        }
    }
}
